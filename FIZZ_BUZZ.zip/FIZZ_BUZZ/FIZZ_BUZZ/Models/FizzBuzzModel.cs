﻿namespace FIZZ_BUZZ.Models
{
    public class FizzBuzzModel
    {
        public List<int>? InputValues { get; set; }
        public List<string>? Results { get; set; }
        public List<string>? DivisionsPerformed { get; set; }
    }
}
